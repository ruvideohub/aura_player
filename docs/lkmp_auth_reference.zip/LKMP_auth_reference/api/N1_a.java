package N1;
/* loaded from: classes.dex */
public interface a {
    void j(d dVar);
}
